/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.ahnlab.enginesdk.SDKLogger;
import com.ahnlab.enginesdk.SDKResultCode;
import com.ahnlab.enginesdk.SDKUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.ProtocolException;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class StoreInfoHttpsClient
{
    private static final String TAG = StoreInfoHttpsClient.class.getSimpleName();

    private final String baseUrl;

    StoreInfoHttpsClient(String url)
    {
        baseUrl = url;
    }

    /**
     * 스토어 데이터 수집 요청
     * 수집되는 데이터는 apiPath에 위치한 엔드포인트로 전송된다.
     * 디바이스에 기본 embed 되어있는 Amazon cacert를 통해 요청을 수행한다.
     * 만약 구버전 디바이스에서 기본 embed 되어있는 요청서가 존재하지 않는다면, 해당 request는 무시된다.
     *
     * @param apiPath 요청 엔드포인트의 상세 path
     * @param param 요청 파라미터로, body json이다.
     * @return 요청에 대한 응답으로, {@link Response#code}, {@link Response#msg}, {@link Response#data}로 구성된다.
     *
     * @since 1.17.0.1
     * */
    @SuppressWarnings("SameParameterValue")
    Response requestCollection(String apiPath, String param){

        SDKLogger.normalLog(TAG, "requested collection to " + baseUrl + apiPath);

        if (baseUrl == null || apiPath == null || param == null)
        {
            return null;
        }

        //No embedded cacert verification on collection
        Response response = new BaseClientSync(baseUrl + apiPath)
                .post(param);

        if (response == null)
        {
            //Connection failed
            //Not even requested
            //Log or sent to ahloha
            SDKLogger.normalLog(TAG, "[requestCollection] response null, failed to request");
        }

        return response;
    }

    Response requestScan(String apiPath, String cerPath, String param){

        SDKLogger.normalLog(TAG, "requested scan to " + baseUrl + apiPath);
        Log.d(TAG, "requested scan to " + baseUrl + apiPath);
        Log.d(TAG, "requested param " + param);

        if (baseUrl == null || apiPath == null || param == null)
        {
            return null;
        }

        long current = System.currentTimeMillis();
        //No embedded cacert verification on collection
        Response response = new BaseClientSync(baseUrl + apiPath)
                .ssl("Amazon", cerPath)
                .post(param);

        Log.d(TAG, "Server scan request took "
                + (System.currentTimeMillis() - current)
                + "ms until response");

        if (response == null)
        {
            //Connection failed
            //Not even requested
            //Log or sent to ahloha
            SDKLogger.normalLog(TAG, "[requestScan] response null, failed to request");
        }

        return response;
    }

    private String readContents(String filePath)
    {
        StringBuilder stringBuilder = new StringBuilder();
        try(BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath)))
        {
            String line;
            while((line = bufferedReader.readLine()) != null)
            {
                stringBuilder.append(line).append("\n");
            }
        }catch (IOException e)
        {
            return null;
        }
        return stringBuilder.toString();
    }

    /**
     * 수집 서버로 데이터 전송 시 파싱 함수
     * 전송 결과에 대한 실패 데이터 파싱
     *
     * @param jsonObject 서버로부터 전달받은 데이터로, 결과 json의 data 필드 값
     * @return 실패한 결과 패키지가 위치한 인덱스
     *
     * @since 1.17.0.1
     */
    Set<Integer> parseStoreFailure(JSONObject jsonObject) {
        Set<Integer> result = new HashSet<>();
        if (jsonObject == null)
        {
            return null;
        }

        JSONObject storeResult = jsonObject.optJSONObject("store");
        if (storeResult == null || storeResult.length() < 1)
        {
            return null;
        }

        JSONArray responseDataFailure = storeResult.optJSONArray("failure");
        if (responseDataFailure == null || responseDataFailure.length() < 1)
        {
            return null;
        }

        for(int index = 0; index < responseDataFailure.length(); index++)
        {
            result.add(responseDataFailure.optInt(index, -1));
        }
        return result;
    }

    /**
     * 검사 서버로 데이터 전송 시 파싱 함수
     * 전송 결과에 대한 검사 완료 데이터 파싱
     *
     * @param jsonObject 서버로부터 전달받은 데이터로, 결과 json의 data 필드 값
     * @return 스캔 결과로, 신뢰 가능 여부와 패키지명의 Map으로 구성
     *
     * @since 1.17.0.1
     */
    Map<String, Integer> parseScanResult(JSONObject jsonObject, ArrayList<String> indexedPackages) {
        Map<String, Integer> result = new HashMap<>();
        if (jsonObject == null)
        {
            return null;
        }
        JSONObject responseDataResult = jsonObject.optJSONObject("scan");
        if (responseDataResult == null || responseDataResult.length() < 1)
        {
            return null;
        }
        Iterator<String> keys = responseDataResult.keys();

        while(keys.hasNext()){
            /*String indexString = keys.next();
            int trusted = responseDataResult.optInt(indexString, StoreInfoConstants.SCANNED_UNKNOWN_PACKAGE);
            try
            {
                String packageName = indexedPackages.get(Integer.parseInt(indexString));
                result.put(packageName, trusted);
            } catch (IndexOutOfBoundsException | NumberFormatException e)
            {
            }*/

            String packageName = keys.next();
            int trusted = responseDataResult.optInt(packageName, StoreInfoConstants.SCANNED_UNKNOWN_PACKAGE);
            Log.d(TAG, "packageName : " + packageName + ", trustedIfZero : " + trusted);
            result.put(packageName, trusted);
        }
        return result;
    }

    @SuppressWarnings("NullableProblems")
    static class Response {
        private final int code;
        private final String msg;
        private final JSONObject data;

        private Response(int code, String msg, JSONObject data) {
            this.code = code;
            this.msg = msg;
            this.data = data;
        }

        int getCode()
        {
            return code;
        }

        String getMsg()
        {
            return msg;
        }

        public JSONObject getData()
        {
            return data;
        }

        @Override
        public String toString()
        {
            return "Response{" + "code=" + code + ", msg='" + msg + '\'' + ", data=" + data + '}';
        }
    }

    private static class BaseClientSync
    {
        HttpsURLConnection conn;
        private static final int CONN_TIMEOUT = 20 * 1000;
        private static final int READ_TIMEOUT = 20 * 1000;
        private static final int REQUEST_TIMEOUT = 10 * 1000;

        /**
         * @param urlString required url string to establish connection
         */
        private BaseClientSync(String urlString)
        {
            try
            {
                URL url = new URL(urlString);
                conn = (HttpsURLConnection) url.openConnection();

            } catch (IOException e)
            {
                conn = null;
            }

            if (conn != null)
            {
                conn.setUseCaches(false);
                conn.setConnectTimeout(CONN_TIMEOUT);
                conn.setReadTimeout(READ_TIMEOUT);
            }
        }

        /**
         * POST 요청 전달
         * return이 null인 경우 connection에 실패한 것으로, request를 전달하지 못한 경우이다 
         * 
         * @param param post body
         * @return post response, synchronized result
         */
        private Response post(final String param)
        {
            if (conn == null)
            {
                return null;
            }

            try
            {
                //Set POST Method
                conn.setDoOutput(true);
                conn.setRequestMethod(StoreInfoConstants.METHOD_POST);

                return Executors.newSingleThreadExecutor()
                        .submit(() -> baseRequest(param))
                        .get(REQUEST_TIMEOUT, TimeUnit.MILLISECONDS);

            } catch (ExecutionException | InterruptedException e)
            {
                postHandleTermination();
                return new Response(SDKResultCode.ERR_FAILURE, e.getMessage(), null);
            } catch (TimeoutException e)
            {
                postHandleTermination();
                return new Response(SDKResultCode.RET_TIMED_OUT, e.getMessage(), null);
            } catch (ProtocolException e)
            {
                postHandleTermination();
                return new Response(SDKResultCode.RET_INVALID_DATA, e.getMessage(), null);
            }
        }

        /**
         * POST 요청 전달을 위한 유틸
         *
         * @param param post body
         * @return response from https connection, or error with null data
         */
        @NonNull
        protected Response baseRequest(@Nullable String param)
        {
            Response result = null;
            String response = null;

            try
            {
                conn.setRequestProperty("content-type", "application/json");
                if (param != null)
                {
                    SDKLogger.debugLog(TAG, "request: " + param);
                    SDKUtils.writeStream(conn, param);
                }

                response = SDKUtils.readStream(conn);
                SDKLogger.debugLog(TAG, "response: " + response);
            } catch (IOException e)
            {
                //This maybe due to client's internet connection
                result = new Response(SDKResultCode.ERR_FAILURE, e.getMessage(), null);
            }

            //If result is still uninitialized (no error occurred)
            if (result == null)
            {
                try
                {
                    //response
                    //parse and check response code
                    JSONObject responseJson = new JSONObject(response);
                    result = new Response(responseJson.optInt("code", SDKResultCode.ERR_FAILURE)
                            , responseJson.optString("msg")
                            , responseJson.optJSONObject("data"));
                } catch (JSONException e)
                {
                    result = new Response(SDKResultCode.RET_INVALID_DATA, e.getMessage(), null);
                }
            }

            postHandleTermination();
            return result;
        }

        private void postHandleTermination()
        {
            if (conn == null)
            {
                return;
            }
            conn.disconnect();
            conn = null;
        }

        private BaseClientSync ssl(String alias, String path)
        {
            SSLContext context;

            try (InputStream caInput = new BufferedInputStream(new FileInputStream(path)))
            {
                Certificate certificate = CertificateFactory
                        .getInstance("X.509")
                        .generateCertificate(caInput);

                // 위에서 생성한 ca를 포함하는 키 스토어 생성
                KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                keyStore.load(null, null);
                keyStore.setCertificateEntry(alias, certificate);

                // trustManager 생성
                TrustManagerFactory factory = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm()
                );
                factory.init(keyStore);

                // SSL Context 생성 및 trustManager 등록
                // trustManager를 지정하지 않으면 인증서 검증 과정 없이 연결이 수행됨 즉 아무 인증서가 와도 연결이 수행됨
                context = SSLContext.getInstance("TLS");
                context.init(null, factory.getTrustManagers(), null);
            } catch (Exception e)
            {
                context = null;
            }

            if (context != null)
            {
                conn.setSSLSocketFactory(context.getSocketFactory());
            }

            return this;
        }
    }
}
