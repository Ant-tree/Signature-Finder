/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.content.Context;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;

import com.ahnlab.enginesdk.MMSVManager;
import com.ahnlab.enginesdk.av.ListScanCallback;
import com.ahnlab.enginesdk.av.ListScanElement;
import com.ahnlab.enginesdk.av.ListScanResult;
import com.ahnlab.enginesdk.av.StoreInfoListScanResult;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class StoreInfoScanner
{
    private static final String TAG = "StoreInfoScanner";

    //If combined with MDTI scan
    private ListScanCallback mCallback = null;
    private ExecutorService executor;

    //possible parameters from list scan callback
    private int listScanResultCode;
    private ListScanResult listScanResult = null;
    private ListScanElement listScanElement = null;

    //Indicates white scan failure at any time
    private boolean storeScanFailed = true;
    private boolean isMdtiCanceled = false;

    private ArrayList<String> trustedPackages = null;

    public StoreInfoScanner()
    {

    }

    public ListScanCallback getMDTICombiner(ListScanCallback callback) {
        this.mCallback = callback;
        return new ListScanCallback() {
            @Override
            public void onUpdateProgress(int progress, int completedCount, int totalCount)
            {
                mCallback.onUpdateProgress(progress, completedCount, totalCount);
            }

            @Override
            public void onComplete(int resultCode, ListScanElement element, ListScanResult scanResult)
            {
                onMDTIScanDone(resultCode, element, scanResult);
            }

            @Override
            public void onCancel(int resultCode, ListScanElement element, ListScanResult scanResult)
            {
                isMdtiCanceled = true;

                terminateIfRunning();
                onMDTIScanDone(resultCode, element, scanResult);
            }

            @Override
            public void onScanError(int errorCode, ListScanElement element)
            {
                mCallback.onScanError(errorCode, element);
            }
        };
    }

    public void scan(final Context context) throws IllegalStateException {
        if(mCallback == null)
        {
            throw new IllegalStateException("ADS Scan cannot run without combined callback");
        }

        //Use handler and background thread
        //Without handler, when whitelist scan ends later than MDTI,
        //Main ui thread cannot process the data from the thread below.
        final Handler handler = new Handler();
        Executors.newSingleThreadExecutor().execute(() -> {
            MMSVManager mmsvManager = MMSVManager.getInstance();
            if (mmsvManager == null)
            {
                return;
            }

            //Skip whitelist scan if not activated
            if(!mmsvManager.getStoreAppScanActivation()
                //Or previous task not finished
                || isTaskRunning())
            {
                storeScanFailed = true;
                handler.post(this::onWhiteScanDone);
                return;
            }

            /*String baseUrlFromMMSV = mmsvManager.getStoreAppScanBaseUrl();
            if (baseUrlFromMMSV == null)
            {
                return;
            }*/

            //final String baseUrl = "https://d7el10pln6.execute-api.ap-northeast-2.amazonaws.com/ahnlab";
            final String baseUrl = "https://qaverify.tds.ahnlab.com";
            //final String baseUrl = StoreInfoConstants.HTTPS + baseUrlFromMMSV;
            final int ttlDays = mmsvManager.getStoreAppScanCacheTTL();
            final Set<String> excluded = mmsvManager.getStoreAppScanExcludedInstaller();

            storeScanFailed = false;

            executor = Executors.newSingleThreadExecutor();
            executor.execute(() -> {
                StoreInfoScannerTask storeInfoScannerTask = new StoreInfoScannerTask(context);

                trustedPackages = storeInfoScannerTask.scanTrustedPackages(baseUrl
                        , ttlDays == 0 //If TTL is not defined in mmsv
                            ? StoreInfoConstants.DEFAULT_SCAN_CACHE_TTL_IN_DAYS
                            : ttlDays
                        , excluded);

            });

            //Shutdown after 5 seconds of termination
            executor.shutdown();

            //isFinished flag is false when timeout, true otherwise
            try
            {
                boolean isInsideTimeLimit = executor.awaitTermination(5, TimeUnit.SECONDS);
                storeScanFailed = !isInsideTimeLimit || (trustedPackages == null);
                Log.d(TAG, "Scan timeout? : " + !isInsideTimeLimit + ", is result null? : " + (trustedPackages == null));

                //If MDTI scan is combined
                handler.post(this::onWhiteScanDone);

            } catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        });
    }

    private void onWhiteScanDone() {
        //Store info scan succeed
        if (!storeScanFailed)
        {
            if(listScanResult != null)
            {
                //MDTI scan is finished, combine both resources and send the result
                sendCombinedResult(trustedPackages, listScanResult);
            }
            //MDTI scan is not finished, should wait for MDTI scan done
            //Setup trusted packages from server response has done on executor
            //Intentionally do nothing
            return;
        }

        //Store info scan failed
        //MDTI scan completed
        if (listScanResult != null && listScanElement != null)
        {
            //list scan result exists
            //Must have been waiting for store scan completion
            //Error must be handled on list scan callback otherwise
            sendMDTIResultOnly(listScanResultCode, listScanElement, listScanResult);
        }
    }

    private void onMDTIScanDone(int resultCode, ListScanElement element, ListScanResult scanResult) {
        Log.d(TAG, "onMDTIScanDone , storeScanFailed : " + storeScanFailed);
        if (storeScanFailed)
        {
            //No store scan data are available
            Log.d(TAG, "No store scan data is available");
            sendMDTIResultOnly(resultCode, element, scanResult);
            return;
        }

        //store scan incomplete
        if (trustedPackages == null)
        {
            //If server request is undone, store the data and waits for its termination
            Log.d(TAG, "server request is undone, store the data and waits for its termination");
            listScanElement = element;
            listScanResultCode = resultCode;
            listScanResult = scanResult;
        } else {
            //Subtract the untrusted packages from scanResult and send
            Log.d(TAG, "Subtract the untrusted packages from scanResult and send");
            sendCombinedResult(trustedPackages, scanResult);
        }
    }

    private void sendCombinedResult(@NonNull ArrayList<String> trustedPackages
            , @NonNull ListScanResult listScanResult)
    {
        StoreInfoListScanResult subtracted = new StoreInfoListScanResult(listScanResult);

        //Do subtraction
        subtracted.subtract(trustedPackages);

        if (isMdtiCanceled)
        {
            mCallback.onCancel(listScanResultCode
                    , listScanElement
                    , subtracted);
        }
        else
        {
            mCallback.onComplete(listScanResultCode
                    , listScanElement
                    , subtracted);
        }
        onAllTasksComplete();
    }

    private void sendMDTIResultOnly(int resultCode, ListScanElement element, ListScanResult scanResult)
    {
        if (isMdtiCanceled)
        {
            mCallback.onCancel(resultCode, element, scanResult);
        }
        else
        {
            mCallback.onComplete(resultCode, element, scanResult);
        }
        onAllTasksComplete();
    }

    /**
     * When all tasks are finished,
     * clear the variables if needed
     * */
    private void onAllTasksComplete()
    {
        //Previous MDTI results
        listScanResultCode = 0;
        listScanResult = null;
        listScanElement = null;
        isMdtiCanceled = false;

        //Previous ADS results
        trustedPackages = null;
        storeScanFailed = true;

        //Callback
        mCallback = null;

        //Single executor
        executor = null;
    }

    private boolean isTaskRunning()
    {
        return (executor != null && !executor.isTerminated());
    }

    public void terminateIfRunning()
    {
        if (executor != null)
        {
            executor.shutdownNow();
        }
    }
}
