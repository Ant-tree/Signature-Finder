/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.support.annotation.NonNull;
import android.util.Log;
import android.util.Pair;

import com.ahnlab.digest.SHA;
import com.ahnlab.enginesdk.SDKLogger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class StoreInfoScannerCache
{
    private static final String TAG = "StoreInfoScannerCache";

    private static final int DAY_IN_MILLIS = 1000 * 60 * 60 * 24;
    static final String ITEM_DELIMITER = "\n";

    static final int CACHE_NOT_EXISTS = 0;
    static final int CACHE_NEEDS_UPDATE = 1;
    static final int CACHE_EXISTS = -1;

    /**
     * Write cache
     * exception 발생 시 현재 저장 중이던 / 저장되어있던 캐시 파일을 삭제한다.
     * load 시점에서 exception이 발생해서 cacheMap을 로드하지 못했을 때는,
     * 새로 생성된 캐시로 덮어씌워 저장하게 된다.
     *
     * 내부에서 데이터에 대한 XOR 비트 마스킹이 발생한다.
     *
     * Static Block Synchronization은 class 단위로 적용된다. (Save 중 Load 불가)
     */
    static void saveCaches(@NonNull String cachePath, @NonNull Map<String, String> cacheItems, @NonNull String key)
    {
        synchronized(StoreInfoScannerCache.class)
        {
            //Serialize list object into byte array
            try(ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
                ObjectOutputStream outputStream = new ObjectOutputStream(byteOutputStream);
                FileOutputStream fileOutputStream = new FileOutputStream(cachePath))
            {
                outputStream.writeObject(cacheItems);
                outputStream.close();
                byte[] data = byteOutputStream.toByteArray();

                //XOR mask the data
                byte[] encrypted = new byte[data.length];
                byte[] sha = SHA.SHA256(key);
                for (int index = 0; index < data.length; index ++)
                {
                    encrypted[index] = (byte)(data[index] ^ sha[index % sha.length]);
                }

                //File out the serialized, masked data
                fileOutputStream.write(encrypted);
            } catch (Exception e)
            {
                SDKLogger.normalLog(TAG, "Save StoreInfo Scanner cache failed due to : " + e.getMessage());
                Log.d(TAG, "Save StoreInfo Scanner cache failed due to : " + e.getMessage());

                File file = new File(cachePath);
                if (file.exists())
                {
                    boolean cacheDelResult = file.delete();
                    SDKLogger.debugLog(TAG, "StoreInfoCache Scanner file removed : " + cacheDelResult);
                }
            }
        }
    }

    /**
     * Read cache
     * IOException은 파일이 존재하지 않을 때 뿐 아니라, CacheItem 클래스 정의가 바뀌었을 때도 발생한다.
     *
     * Static Block Synchronization은 class 단위로 적용된다. (Load 중 Save 불가)
     *
     * 내부에서 데이터에 대한 XOR 비트 언마스킹이 발생한다.
     */
    @SuppressWarnings("unchecked")
    @NonNull
    static Map<String, String> loadScanCaches(@NonNull String cachePath, @NonNull String key)
    {
        synchronized(StoreInfoScannerCache.class)
        {
            Map<String, String> cacheMap = new HashMap<>();
            File cacheFile = new File(cachePath);
            if (!cacheFile.exists())
            {
                return cacheMap;
            }

            byte[] decrypted;
            try (FileInputStream fileInputStream = new FileInputStream(cacheFile))
            {
                byte[] encrypted = new byte[(int) cacheFile.length()];
                int read = fileInputStream.read(encrypted);
                if (read != cacheFile.length())
                {
                    return cacheMap;
                }

                //XOR unmask the data
                decrypted = new byte[encrypted.length];
                byte[] sha = SHA.SHA256(key);
                for (int index = 0; index < encrypted.length; index ++)
                {
                    decrypted[index] = (byte)(encrypted[index] ^ sha[index % sha.length]);
                }
            } catch (Exception e)
            {
                //File not found or error occurs
                SDKLogger.normalLog(TAG, "Load file data failed, due to : " + e.getMessage());
                return cacheMap;
            }

            //Deserialize list
            try(ByteArrayInputStream byteInputStream = new ByteArrayInputStream(decrypted);
                    ObjectInputStream inputStream = new ObjectInputStream(byteInputStream))
            {
                cacheMap = (Map<String, String>) inputStream.readObject();
            } catch (IOException | ClassNotFoundException e)
            {
                SDKLogger.normalLog(TAG, "Deserialize failed, due to : " + e.getMessage());
            }
            return cacheMap;
        }
    }

    static int checkCacheContains(Map<String, String> cacheMap, String packageName, String certCRC, int ttlDays)
    {
        if (cacheMap == null || cacheMap.size() < 1)
        {
            return CACHE_NOT_EXISTS;
        }

        if(cacheMap.containsKey(packageName))
        {
            String rawValue = cacheMap.get(packageName);

            //if cacheKey was found from map, but data is null
            if (rawValue == null)
            {
                //purge out the key and return "CACHE_NOT_EXISTS"
                cacheMap.remove(packageName);
                return CACHE_NOT_EXISTS;
            }

            String[] parsed = rawValue.split(ITEM_DELIMITER);
            if(parsed.length != 2)
            {
                //purge out the key and return "CACHE_NOT_EXISTS"
                cacheMap.remove(packageName);
                return CACHE_NOT_EXISTS;
            }

            //Parse expiration from value
            long expiration;
            try
            {
                expiration = Long.parseUnsignedLong(parsed[1]);
            } catch (NumberFormatException ignore)
            {
                cacheMap.remove(packageName);
                return CACHE_NOT_EXISTS;
            }

            String cachedCertCRC = parsed[0];
            boolean cacheExpired = (System.currentTimeMillis() - (long) ttlDays * DAY_IN_MILLIS) > expiration;

            //If cached item has different cert CRC
            //cacheMap needs to be updated accordingly
            if (!Objects.equals(cachedCertCRC, certCRC) || cacheExpired)
            {
                //purge out the key and return "CACHE_NEEDS_UPDATE"
                cacheMap.remove(packageName);
                return CACHE_NEEDS_UPDATE;
            }

            //Data exists
            return CACHE_EXISTS;
        }

        return CACHE_NOT_EXISTS;
    }
}
