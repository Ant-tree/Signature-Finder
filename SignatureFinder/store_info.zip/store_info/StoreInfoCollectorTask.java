/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.Log;

import com.ahnlab.enginesdk.SDKLogger;
import com.ahnlab.enginesdk.SDKManager;
import com.ahnlab.enginesdk.SDKResultCode;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class StoreInfoCollectorTask
{
    private static final String TAG = StoreInfoCollectorTask.class.getSimpleName();
    /**
     * Key : packageName
     * Value : CacheItem
     * */
    private Map<String, StoreInfoCache.CacheItem> cacheMap = new HashMap<>();
    //HttpsClient for store info collection request
    private final StoreInfoHttpsClient httpsClient;

    //Base DIR (ahnlab/engine/)
    private String baseDir = null;
    //context from parent
    private final Context context;
    //AVOperation flag from mmsv manager -> StoreInfoCollector
    private final int operationFlag;

    //TaskObserver interface for task completion
    private StoreInfoCollectorTaskObserver listener;
    //Excluded installer package name from collection
    private Set<String> excludes = new HashSet<>();
    //flag to exclude null installer package name, exclude if true
    private boolean excludeNull = false;

    /**
     * 생성자에서는 모든 동작에 반드시 필요한 데이터들을 받아온다
     *
     * @param opFlag 가 없는 경우에는 Cert cache 조회가 불가능
     * @param baseUrl 이 없는 경우에는 전송할 서버를 식별할 수 없다.
     *
     * */
    StoreInfoCollectorTask(Context context, int opFlag, String baseUrl)
    {
        this.context = context;
        this.operationFlag = opFlag;
        httpsClient = new StoreInfoHttpsClient(baseUrl);
    }

    /**
     * Optional
     * 태스크 종료 시 이벤트를 획득할 listener를 등록한다.
     * @param listener event listener
     * @return this
     * */
    StoreInfoCollectorTask listen(StoreInfoCollectorTaskObserver listener)
    {
        this.listener = listener;
        return this;
    }

    /**
     * Optional
     * 특정 인스톨러 패키지명을 제외하기 위한 리스트를 설정한다.
     * @param excludes 제외할 인스톨러 패키지명 리스트
     *                 해당 리스트에 정의된 인스톨러 패키지명에 해당하면 서버에 전달할
     *                 request data에 포함하지 않는다.
     * @return this
     * */
    StoreInfoCollectorTask exclude(Set<String> excludes)
    {
        return exclude(excludes, false);
    }

    StoreInfoCollectorTask exclude(Set<String> excludes, boolean excludeNull)
    {
        this.excludes = excludes;
        this.excludeNull = excludeNull;
        return this;
    }

    /**
     * Store info 조회 및 전송 시작
     *
     * */
    int startCollection()
    {
        SDKLogger.normalLog(TAG, "startCollection");
        baseDir = context.getFilesDir() + StoreInfoConstants.engineDir;
        cacheMap = StoreInfoCache.loadCacheStoreInfo(baseDir 
                + StoreInfoConstants.storeCachePath
                , context.getPackageName());

        //This packagesForRequest will be used to parse partially failed packages
        ArrayList<String> packagesForRequest = new ArrayList<>();
        JSONObject requestData = new JSONObject();
        JSONObject jsonObject = getRequestData(packagesForRequest);

        if (jsonObject == null)
        {
            onComplete(null);
            return SDKResultCode.ERR_NOERROR;
        }
        try
        {
            requestData.put("storeData", jsonObject);
        } catch (JSONException e)
        {
            onComplete(null);
            return SDKResultCode.ERR_FAILURE;
        }

        SDKLogger.normalLog(TAG, "Collection data size : " + jsonObject.length());
        //http connection
        StoreInfoHttpsClient.Response response 
                = httpsClient.requestCollection(StoreInfoConstants.apiPath
                , requestData.toString());

        //onComplete
        if (response != null)
        {
            //Parse response, save as a cache
            processOnResponse(response, packagesForRequest);
        }

        onComplete(response != null ? response.getMsg() : null);
        return SDKResultCode.ERR_NOERROR;
    }

    private void processOnResponse(StoreInfoHttpsClient.Response response, ArrayList<String> requested)
    {
        //+--------------------------------+
        //         PARTIAL SUCCESS
        //+--------------------------------+
        if (response.getCode() == SDKResultCode.RET_PARTIAL_SUCCESS)
        {
            Set<Integer> failed = httpsClient.parseStoreFailure(response.getData());
            if (failed == null)
            {
                return;
            }

            StringBuilder reason = new StringBuilder();
            for(int index : failed)
            {
                if (index == -1)
                {
                    continue;
                }
                String failedPackage = requested.get(index);
                cacheMap.remove(failedPackage);
                reason.append(failedPackage).append("\n");
            }

            //Save partial cache
            StoreInfoCache.saveCacheStoreInfo(
                    baseDir + StoreInfoConstants.storeCachePath
                    , cacheMap
                    , context.getPackageName());
            SDKLogger.normalLog(TAG, "Collection on " + (cacheMap.size() - failed.size()) + " apps were partially successful");
            logOnFailure(response.getCode(), reason.toString());
        }
        //+--------------------------------+
        //              FAILED
        //+--------------------------------+
        else if(response.getCode() < 0)
        {
            logOnFailure(response.getCode(), response.getMsg());
        }
        //+--------------------------------+
        //              SUCCESS
        //+--------------------------------+
        else
        {
            //Save whole cache as-is
            StoreInfoCache.saveCacheStoreInfo(
                    baseDir + StoreInfoConstants.storeCachePath
                    , cacheMap
                    , context.getPackageName());

            SDKLogger.normalLog(TAG, "Collection on " + cacheMap.size() + " apps successful");
        }
    }

    /**
     * 요청 전송을 위한 request 데이터 조합 및 반환
     * */
    private JSONObject getRequestData(/* OUT */ ArrayList<String> packageForRequest) {
        JSONObject jsonObject = new JSONObject();
        int formatVersion = getFormatVersion();
        if (formatVersion < 0)
        {
            //Unable to obtain format version
            return null;
        }
        PackageManager packageManager = context.getPackageManager();

        @SuppressLint("QueryPermissionsNeeded")
        List<ApplicationInfo> installed = packageManager.getInstalledApplications(0);
        for (ApplicationInfo info : installed)
        {
            String packageName = info.packageName;
            int versionCode;
            String versionName;
            int cacheResult;

            //Skip if is system app
            if((info.flags & ApplicationInfo.FLAG_SYSTEM) == 1)
            {
                continue;
            }

            if(jsonObject.length() >= StoreInfoConstants.BATCH_SINGLE_REQUEST_LIMIT)
            {
                break;
            }

            //Get installed source info - installer information
            String installerPackageName = getInstallerPackageName(packageManager, packageName);

            //installer package name is "" if exception occurred
            if (Objects.equals(installerPackageName, ""))
            {
                continue;
            }

            try
            {
                PackageInfo packageInfo = packageManager.getPackageInfo(packageName, 0);
                versionCode = packageInfo.versionCode;
                versionName = packageInfo.versionName == null ? StoreInfoConstants.undefinedVersion : packageInfo.versionName;
            } catch (PackageManager.NameNotFoundException e)
            {
                continue;
            }

            //Check and send installer
            //if excludeNull is on : skip package if name is null
            if ((excludeNull && installerPackageName == null)
                    || checkPackageExclusion(installerPackageName))
            {
                continue;
            }

            //installerPackageName is not null
            String publicSourceDir = info.publicSourceDir;

            //Skip if this app is not located any directory
            if(publicSourceDir == null)
            {
                continue;
            }

            File apk = new File(publicSourceDir);

            long mTime = apk.lastModified() / 1000; //ms -> s
            long stSize = apk.length();

            SDKManager sdkManager = SDKManager.getInstance();
            if (sdkManager == null)
            {
                continue;
            }
            //Assemble a crc64 to make cache prefix
            String pathCrc = Long.toUnsignedString(
                    sdkManager.updateACRC64(apk.getAbsolutePath().getBytes())
            );

            //Get the Cert CRC from cache
            String certCrc = readCertCache(apk.getName()
                    , mTime
                    , stSize
                    , operationFlag
                    , formatVersion
                    , pathCrc);

            //If certCrc is null, mdti scan has never been done on that app
            if (certCrc == null)
            {
                continue;
            }

            //Check cache (Local storeInfo cache)
            if ((cacheResult = StoreInfoCache.checkCacheContains(cacheMap
                    , packageName
                    , versionCode
                    , installerPackageName
                    , certCrc)) == StoreInfoCache.CACHE_EXISTS)
            {
                continue;
            }

            //Store the result in current cache map
            cacheMap.put(packageName, new StoreInfoCache.CacheItem(packageName
                    , mTime                     // Last updated time in seconds
                    , stSize                    // APK file size
                    , certCrc                   // Cert CRC from MDTI cache
                    , installerPackageName      // Installer package name
                    , versionCode               // Current version code (int)
                    , versionName));            // Current version name (String)

            try
            {
                JSONObject packageData = new JSONObject();
                packageData.put("key", certCrc + "-" + installerPackageName);
                packageData.put("updated", cacheResult);
                packageData.put("versionName", versionName);

                jsonObject.put(packageName, packageData);
                packageForRequest.add(packageName);
            } catch (JSONException ignore) { }
        }

        if (jsonObject.length() > 0)
        {
            return jsonObject;
        }
        else
        {
            return null;
        }
    }

    /**
     * 인스톨러 패키지명 제외 여부 확인
     * 인스톨러가 제외된 패키지명에 해당되는 경우는 전송 대상에 포함되지 않음
     *
     * @param installerPackageName 인스톨러 패키지명
     * @return 제외 여부 반환, true 시 제외 패키지명
     * */
    private boolean checkPackageExclusion(String installerPackageName) {
        if (excludes == null)
        {
            return false;
        }
        for(String exclusion : excludes)
        {
            if (Objects.equals(installerPackageName, exclusion))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * PackageName을 기반으로 installer 패키지 이름 획득
     *
     * @param packageManager 정보 조회를 위한 PackageManager
     * @param packageName 조회를 위한 대상 패키지명
     * @return installer package name, null if exception occurs
     * */
    private @Nullable String getInstallerPackageName(PackageManager packageManager, String packageName)
    {
        try
        {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    ? packageManager.getInstallSourceInfo(packageName).getInstallingPackageName()
                    : packageManager.getInstallerPackageName(packageName);
        } catch (PackageManager.NameNotFoundException | IllegalArgumentException e)
        {
            //Given package is not installed
            return "";
        }
    }

    /**
     * MDTI 검사 시 획득한 cert 정보에 대해 캐시를 저장하므로, 해당 캐시를 조회하여 cert crc 획득
     * .ancert파일을 기준으로 Cert hash를 획득한다.
     * 
     * @param filename 파일의 이름
     * @param mTime 파일의 mtime, stat 기준으로, lastUpdateTime 사용 시 ms -> s 변환 필요
     * @param size 파일 사이즈
     * @param opFlag operation flag
     * @param format 룰 파일의 포맷 (v3mobiled.v3d) 파일
     * @param crc 전체 경로에 대한 CRC
     * 
     * @return Cert CRC 값, 찾을 수 없는 경우 null 반환
     * */
    private String readCertCache(String filename, long mTime, long size, int opFlag, int format, String crc)
    {
        String cacheName = String.format(Locale.US
                , "%s%s-%d%d%d%d%s"
                , baseDir + StoreInfoConstants.cachesDir, filename, mTime, size, opFlag, format, crc);

        File cache;

        // Find cached file
        // Find with cache.ancert (MDTI)
        cache = new File(cacheName + StoreInfoConstants.certExt);
        if (!cache.exists())
        {
            cache = null;
        }

        //if both files are not exist, return null
        if (cache == null)
        {
            return null;
        }

        // Read Cert crc based on cache file
        byte[] data = fileReader(cache);
        if(data == null)
        {
            return null;
        }

        int integrity = ByteBuffer.wrap(reversedArray(data, 0, 4)).getInt();
        if (integrity != cache.length())
        {
            return null;
        }

        return reversedHex(data, 4, 8);
    }

    /**
     * 파일 데이터 reader
     * 파일 내부 데이터를 읽어서 byte array로 반환한다.
     *
     * @param file 대상 파일
     * @return 데이터 byte array
     * */
    private byte[] fileReader(File file){
        return fileReader(file, 0, (int) file.length());
    }

    /**
     * 파일 데이터 reader
     * 특정 위치에서부터 특정 길이까지의 결과를 반환한다.
     *
     * @param file 대상 파일
     * @param offset 파일 read 시작 위치 offset (0 + offset)
     * @param length 목표한 파일 read 길이
     * @return 데이터 byte array
     * */
    private byte[] fileReader(File file, int offset, int length){
        byte[] data = new byte[length];
        //ByteBuffer data = ByteBuffer.allocateDirectly(length)

        try (FileInputStream fileInputStream = new FileInputStream(file))
        {
            if (offset > 0)
            {
                fileInputStream.getChannel().position(offset);
            }
            //int resultLength = fileInputStream.getChannel().read(data, length);
            int resultLength = fileInputStream.read(data, 0, length);
            // if read bytes length and cache file size doesn't match
            // possible assumption - not available to read full file contents
            if (resultLength != length)
            {
                //Something went wrong!
                return null;
            }

        } catch (IOException e)
        {
            //Any exception while reading
            return null;
        }

        return data;
    }

    /**
     * Reverse the array
     * */
    @SuppressWarnings("SameParameterValue")
    private byte[] reversedArray(byte[] origin, int startIndex, int length) {
        int size = origin.length;
        byte[] result = new byte[size];

        for (int index = startIndex; index < length; index++)
        {
            result[index] = origin[length - (1 + index)];
        }
        return result;
    }

    /**
     * Reverse the array and convert it into a hex string
     * */
    @SuppressWarnings("SameParameterValue")
    private String reversedHex(byte[] origin, int startIndex, int length) {
        StringBuilder hex = new StringBuilder();

        for (int index = 0; index < length; index++)
        {
            int position = (length + startIndex) - (1 + index);
            hex.append(String.format(Locale.US
                    , "%02x", origin[position])
            );
        }
        return hex.toString();
    }

    /**
     * Get v3d format version int
     * */
    private int getFormatVersion() {
        byte[] version = new byte[1];
        File v3d = new File(baseDir + StoreInfoConstants.dataFile);
        if (!v3d.exists()) {
            return SDKResultCode.RET_NOT_EXISTS;
        }

        try (RandomAccessFile randomAccessFile = new RandomAccessFile(v3d, "r"))
        {
            randomAccessFile.seek(47);
            int read = randomAccessFile.read(version, 0, 1);
            if (read != 1)
            {
                return SDKResultCode.RET_ERR_FILE_READ;
            }
        } catch (FileNotFoundException e)
        {
            return SDKResultCode.RET_NOT_EXISTS;
        } catch (IOException e)
        {
            return SDKResultCode.ERR_FAILURE;
        }

        return version[0];
    }

    private void onComplete(String msg)
    {
        if (listener != null)
        {
            listener.onComplete(msg);
        }
    }

    private void logOnFailure(int code, String reason)
    {
        SDKLogger.normalLog(TAG, "Failed with code : " + code + ", reason : "+ reason);
        /*AHLOHAClient.sendError(SDKManager.ENGINE_ID.ANTI_VIRUS
                , SDKCommand.ANTI_VIRUS.SEND_HTTPS_REQUEST
                , "("+code+")"+reason);*/
    }
}
