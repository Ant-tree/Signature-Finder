/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.support.annotation.NonNull;

import com.ahnlab.digest.SHA;
import com.ahnlab.enginesdk.SDKLogger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class StoreInfoCache
{
    private static final String TAG = "StoreInfoCache";

    static final int CACHE_NOT_EXISTS = 0;
    static final int CACHE_NEEDS_UPDATE = 1;
    static final int CACHE_EXISTS = -1;

    static class CacheItem implements Serializable
    {
        private final String packageName;
        private final String certCrc;
        private final String installer;
        private final int versionCode;
        private final String versionName;
        private final long mTimeSeconds;
        private final long size;

        private static final String DELIMITER = "\n";
        private static final int FIELD_NUMBER = 7;

        private CacheItem(String bundledItems) {
            String[] split = bundledItems.split(DELIMITER);
            //If failed to parse from bundled up items
            if (split.length != FIELD_NUMBER)
            {
                this.packageName = null;
                this.certCrc = null;
                this.installer = null;
                this.versionCode = 0;
                this.versionName = null;
                this.mTimeSeconds = 0;
                this.size = 0;
                return;
            }
            this.packageName    = (Objects.equals(split[0], "") ? null : split[0]);
            this.certCrc        = (Objects.equals(split[1], "") ? null : split[1]);
            this.installer      = (Objects.equals(split[2], "") ? null : split[2]);

            int versionCode = 0;
            try
            {
                versionCode     = Integer.parseInt(split[3]);
            } catch (NumberFormatException ignored) { }
            this.versionCode    = versionCode;
            this.versionName    = split[4];

            long mTimeSeconds = 0;
            try
            {
                mTimeSeconds    = Long.parseLong(split[5]);
            } catch (NumberFormatException ignored) { }
            this.mTimeSeconds   = mTimeSeconds;

            long size = 0;
            try
            {
                size            = Long.parseLong(split[6]);
            } catch (NumberFormatException ignored) { }
            this.size           = size;
        }

        CacheItem (@NonNull String packageName
                , long mTimeSeconds
                , long size
                , @NonNull String certCrc
                , String installer
                , int versionCode
                , String versionName) {

            this.packageName = packageName;
            this.mTimeSeconds = mTimeSeconds;
            this.size = size;
            this.certCrc = certCrc;
            this.installer = installer;
            this.versionCode = versionCode;
            this.versionName = versionName;
        }

        public String getPackageName()
        {
            return packageName;
        }

        public String getCertCrc()
        {
            return certCrc;
        }

        public String getInstaller()
        {
            return installer;
        }

        public long getmTimeSeconds()
        {
            return mTimeSeconds;
        }

        public long getSize()
        {
            return size;
        }

        public int getVersionCode()
        {
            return versionCode;
        }

        public String getVersionName()
        {
            return versionName;
        }

        private String bundleUp()
        {
            return packageName + DELIMITER
                    + certCrc + DELIMITER
                    + (installer == null ? "" : installer) + DELIMITER
                    + versionCode + DELIMITER
                    + (versionName == null ? "" : versionName) + DELIMITER
                    + mTimeSeconds + DELIMITER
                    + size;
        }
    }

    /**
     * Write cache
     * exception 발생 시 현재 저장 중이던 / 저장되어있던 캐시 파일을 삭제한다.
     * load 시점에서 exception이 발생해서 cacheMap을 로드하지 못했을 때는,
     * 새로 생성된 캐시로 덮어씌워 저장하게 된다.
     *
     * 내부에서 데이터에 대한 XOR 비트 마스킹이 발생한다.
     *
     * Static Block Synchronization은 class 단위로 적용된다. (Save 중 Load 불가)
     */
    static void saveCacheStoreInfo(@NonNull String cachePath, @NonNull Map<String, CacheItem> cacheMap, @NonNull String key)
    {
        synchronized(StoreInfoCache.class)
        {
            //Convert CacheItems in cacheMap into String ArrayList
            //to properly apply proguard obfuscation
            ArrayList<String> list = new ArrayList<>();

            for (CacheItem cacheItem : cacheMap.values())
            {
                list.add(cacheItem.bundleUp());
            }

            if (list.size() < 1)
            {
                return;
            }

            //Serialize list object into byte array
            try(ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
                ObjectOutputStream outputStream = new ObjectOutputStream(byteOutputStream);
                FileOutputStream fileOutputStream = new FileOutputStream(cachePath))
            {
                outputStream.writeObject(list);
                outputStream.close();
                byte[] data = byteOutputStream.toByteArray();

                //XOR mask the data
                byte[] encrypted = new byte[data.length];
                byte[] sha = SHA.SHA256(key);
                for (int index = 0; index < data.length; index ++)
                {
                    encrypted[index] = (byte)(data[index] ^ sha[index % sha.length]);
                }

                //File out the serialized, masked data
                fileOutputStream.write(encrypted);
            } catch (Exception e)
            {
                SDKLogger.normalLog(TAG, "Save StoreInfo cache failed due to : " + e.getMessage());

                File file = new File(cachePath);
                if (file.exists())
                {
                    boolean cacheDelResult = file.delete();
                    SDKLogger.debugLog(TAG, "StoreInfoCache file removed : " + cacheDelResult);
                }
            }
        }
    }

    /**
     * Read cache
     * IOException은 파일이 존재하지 않을 때 뿐 아니라, CacheItem 클래스 정의가 바뀌었을 때도 발생한다.
     *
     * Static Block Synchronization은 class 단위로 적용된다. (Load 중 Save 불가)
     *
     * 내부에서 데이터에 대한 XOR 비트 언마스킹이 발생한다.
     */
    @SuppressWarnings("unchecked")
    static Map<String, CacheItem> loadCacheStoreInfo(@NonNull String cachePath, @NonNull String key)
    {
        synchronized(StoreInfoCache.class)
        {
            Map<String, CacheItem> cacheMap = new HashMap<>();
            File cacheFile = new File(cachePath);
            if (!cacheFile.exists())
            {
                return cacheMap;
            }

            byte[] decrypted;
            try (FileInputStream fileInputStream = new FileInputStream(cacheFile))
            {
                byte[] encrypted = new byte[(int) cacheFile.length()];
                int read = fileInputStream.read(encrypted);
                if (read != cacheFile.length())
                {
                    return cacheMap;
                }

                //XOR unmask the data
                decrypted = new byte[encrypted.length];
                byte[] sha = SHA.SHA256(key);
                for (int index = 0; index < encrypted.length; index ++)
                {
                    decrypted[index] = (byte)(encrypted[index] ^ sha[index % sha.length]);
                }
            } catch (Exception e)
            {
                //File not found or error occurs
                SDKLogger.normalLog(TAG, "Load file data failed, due to : " + e.getMessage());
                return cacheMap;
            }

            //Deserialize list
            ArrayList<String> list;
            try(ByteArrayInputStream byteInputStream = new ByteArrayInputStream(decrypted);
                    ObjectInputStream inputStream = new ObjectInputStream(byteInputStream))
            {
                list = (ArrayList<String>) inputStream.readObject();
                for(String cacheItemString : list)
                {
                    CacheItem cacheItem = new CacheItem(cacheItemString);
                    cacheMap.put(cacheItem.packageName, cacheItem);
                }
            } catch (IOException | ClassNotFoundException e)
            {
                SDKLogger.normalLog(TAG, "Deserialize failed, due to : " + e.getMessage());
            }
            return cacheMap;
        }
    }

    static int checkCacheContains(Map<String, CacheItem> cacheMap, String packageName, int versionCode, String installer, String certCRC)
    {
        if (cacheMap == null || cacheMap.size() < 1)
        {
            return CACHE_NOT_EXISTS;
        }

        if(cacheMap.containsKey(packageName))
        {
            CacheItem item = cacheMap.get(packageName);

            //if cacheKey was found from map, but data is null
            if (item == null)
            {
                //purge out the key and return "CACHE_NOT_EXISTS"
                cacheMap.remove(packageName);
                return CACHE_NOT_EXISTS;
            }

            //If cached item has different "cert CRC" or different installer
            //+ has different versionCode
            //cacheMap needs to be updated accordingly
            if (!Objects.equals(item.getVersionCode(), versionCode)
                    || !Objects.equals(item.getCertCrc(), certCRC)
                    || !Objects.equals(item.getInstaller(), installer))
            {
                //purge out the key and return "CACHE_NEEDS_UPDATE"
                cacheMap.remove(packageName);
                return CACHE_NEEDS_UPDATE;
            }

            //Data exists, and updated times are same
            return CACHE_EXISTS;
        }

        return CACHE_NOT_EXISTS;
    }
}
