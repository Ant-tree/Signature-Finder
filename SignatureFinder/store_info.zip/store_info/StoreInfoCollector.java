/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.content.Context;
import android.net.ConnectivityManager;

import com.ahnlab.enginesdk.MMSVManager;
import com.ahnlab.enginesdk.SDKLogger;
import com.ahnlab.enginesdk.SDKResultCode;
import com.ahnlab.enginesdk.SDKUtils;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class StoreInfoCollector
{
    private static final String TAG = StoreInfoCollector.class.getSimpleName();

    //Exclude the installers with these package names from MMSV
    private Set<String> exclusionInstallerPackages;
    //AV Operation flag from MMSV manager
    private int operationFlag;
    //Server Base URL from MMSV manager
    private String baseUrl;
    //Ignore null installer if true
    private boolean ignoreNullInstaller = false;

    private ExecutorService executor;

    private boolean isRunning = false;

    private static volatile StoreInfoCollector instance;

    public static StoreInfoCollector getInstance()
    {
        if (instance == null)
        {
            synchronized (StoreInfoCollector.class)
            {
                if (instance == null)
                {
                    instance = new StoreInfoCollector();
                }
            }
        }
        return instance;
    }

    /**
     * Store info 조회 및 전송 시작
     * 조회 및 전송은 executor를 통해서 비동기로 동작된다. 만약 네트워크 상태 등의 이유로
     * 조건에 해당되지 않아 전송이 불가능한 상태라면 executor에 작업이 등록되지 않는다.
     * 내부적으로 CachedThreadPool을 사용하므로, 작업이 종료되기 전에 너무 많은 수의 작업이 지속적으로 등록되어서는 안된다.
     *
     * @since 1.17.0.1
     * @see com.ahnlab.enginesdk.AntiVirus
     * @return executor 정상 등록 여부
     * */
    public int collectStoreInfo(final Context context)
    {
        SDKLogger.normalLog(TAG, "collectStoreInfo entered");

        if (isRunning)
        {
            SDKLogger.normalLog(TAG, "collector busy");
            return SDKResultCode.RET_ALREADY;
        }

        if (!getConditionalStartOptions(context))
        {
            return SDKResultCode.ERR_FAILURE;
        }

        synchronized (this)
        {
            if (isRunning)
            {
                SDKLogger.normalLog(TAG, "collector busy");
                return SDKResultCode.RET_ALREADY;
            }

            //Cached Thread Pool
            //Use cached thread (unused for 60 seconds) if available
            //Create a new thread otherwise(for example like no thread is currently in idle state)
            //initial core thread number is 0, and can be flexibly maintain until it reaches maximum int range
            executor = Executors.newCachedThreadPool();

            //Can also be implemented in custom way
            //executor = new ThreadPoolExecutor(0       // Initial thread size
            //        , 1                               // Max thread size
            //        , 120L                            // Keep alive time on idle, purge if exceeds
            //        , TimeUnit.SECONDS                // Keep-alive-time-unit
            //        , new SynchronousQueue<>());

            isRunning = true;

            //Runnable task for executor thread
            executor.submit(() -> {
                StoreInfoCollectorTask task = new StoreInfoCollectorTask(context, operationFlag, baseUrl);

                int result = task.listen(data -> {
                    SDKLogger.normalLog(TAG, "Collection task finished with response : " + data);
                    isRunning = false;
                }).exclude(exclusionInstallerPackages, ignoreNullInstaller).startCollection();

                SDKLogger.normalLog(TAG, "collectStoreInfo result : " + result);
            });
        }

        return SDKResultCode.ERR_NOERROR;
    }

    private boolean getConditionalStartOptions(Context context) {
        MMSVManager mmsvManager = MMSVManager.getInstance();
        if (mmsvManager == null)
        {
            return false;
        }

        //Check activation
        if(!mmsvManager.isStoreAppActivation())
        {
            SDKLogger.normalLog(TAG, "Store info collection disabled");
            return false;
        }

        //check sender package
        if(!mmsvManager.isStoreAppIsSenderPackages())
        {
            SDKLogger.normalLog(TAG, "Store info collection not a target (package)");
            return false;
        }

        //calculated Ratio
        if(!mmsvManager.isStoreAppRatioTarget())
        {
            SDKLogger.normalLog(TAG, "Store info collection not a target (ratio)");
            return false;
        }

        boolean isWifiOnly = mmsvManager.isStoreAppSendWifiOnly();
        if(isWifiOnly && SDKUtils.getConnectedNetworkType(context) != ConnectivityManager.TYPE_WIFI)
        {
            SDKLogger.normalLog(TAG, "Store info collection not a target (net state)");
            return false;
        }

        exclusionInstallerPackages = mmsvManager.getStoreAppExcludedInstallers();
        for (String item : exclusionInstallerPackages)
        {
            if (item.equalsIgnoreCase("null"))
            {
                this.ignoreNullInstaller = true;
                break;
            }
        }
        if (ignoreNullInstaller)
        {
            exclusionInstallerPackages.remove("null");
        }

        operationFlag = mmsvManager.getAvOperationCtrlFlag();

        String urlFromMMSV = mmsvManager.getStoreAppBaseUrl();
        if (urlFromMMSV == null || urlFromMMSV.length() < 1)
        {
            return false;
        }
        baseUrl = StoreInfoConstants.HTTPS + urlFromMMSV;
        return true;
    }

    public synchronized void shutdownAllTasks()
    {
        if (!isRunning || executor == null)
        {
            return;
        }
        List<Runnable> remaining = executor.shutdownNow();
        SDKLogger.normalLog(TAG, "shutdown all tasks. not started: " + remaining.size() + "tasks");
        isRunning = false;
    }

}
