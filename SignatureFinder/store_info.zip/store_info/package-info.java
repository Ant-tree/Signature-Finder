/**
 * 위협 정보 검사 시 스토어 정보 수집을 위한 패키지이다.
 */
package com.ahnlab.enginesdk.store_info;