/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.support.annotation.GuardedBy;
import android.support.annotation.NonNull;
import android.util.Log;

import java.lang.annotation.Retention;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;

public class CRC64
{

    private static final String POLY64REV = "D800000000000000";
    private static final String INITIALCRC64 = "0000000019950315";
    private static volatile CRC64 instance;
    private boolean prepared = false;

    long ACRC64_Table[] = {
        0x0000000000000000L, 0x42f0e1eba9ea3693L,
                0x85e1c3d753d46d26L, 0xc711223cfa3e5bb5L,
                0x493366450e42ecdfL, 0x0bc387aea7a8da4cL,
                0xccd2a5925d9681f9L, 0x8e224479f47cb76aL,
                0x9266cc8a1c85d9beL, 0xd0962d61b56fef2dL,
                0x17870f5d4f51b498L, 0x5577eeb6e6bb820bL,
                0xdb55aacf12c73561L, 0x99a54b24bb2d03f2L,
                0x5eb4691841135847L, 0x1c4488f3e8f96ed4L,
                0x663d78ff90e185efL, 0x24cd9914390bb37cL,
                0xe3dcbb28c335e8c9L, 0xa12c5ac36adfde5aL,
                0x2f0e1eba9ea36930L, 0x6dfeff5137495fa3L,
                0xaaefdd6dcd770416L, 0xe81f3c86649d3285L,
                0xf45bb4758c645c51L, 0xb6ab559e258e6ac2L,
                0x71ba77a2dfb03177L, 0x334a9649765a07e4L,
                0xbd68d2308226b08eL, 0xff9833db2bcc861dL,
                0x388911e7d1f2dda8L, 0x7a79f00c7818eb3bL,
                0xcc7af1ff21c30bdeL, 0x8e8a101488293d4dL,
                0x499b3228721766f8L, 0x0b6bd3c3dbfd506bL,
                0x854997ba2f81e701L, 0xc7b97651866bd192L,
                0x00a8546d7c558a27L, 0x4258b586d5bfbcb4L,
                0x5e1c3d753d46d260L, 0x1cecdc9e94ace4f3L,
                0xdbfdfea26e92bf46L, 0x990d1f49c77889d5L,
                0x172f5b3033043ebfL, 0x55dfbadb9aee082cL,
                0x92ce98e760d05399L, 0xd03e790cc93a650aL,
                0xaa478900b1228e31L, 0xe8b768eb18c8b8a2L,
                0x2fa64ad7e2f6e317L, 0x6d56ab3c4b1cd584L,
                0xe374ef45bf6062eeL, 0xa1840eae168a547dL,
                0x66952c92ecb40fc8L, 0x2465cd79455e395bL,
                0x3821458aada7578fL, 0x7ad1a461044d611cL,
                0xbdc0865dfe733aa9L, 0xff3067b657990c3aL,
                0x711223cfa3e5bb50L, 0x33e2c2240a0f8dc3L,
                0xf4f3e018f031d676L, 0xb60301f359dbe0e5L,
                0xda050215ea6c212fL, 0x98f5e3fe438617bcL,
                0x5fe4c1c2b9b84c09L, 0x1d14202910527a9aL,
                0x93366450e42ecdf0L, 0xd1c685bb4dc4fb63L,
                0x16d7a787b7faa0d6L, 0x5427466c1e109645L,
                0x4863ce9ff6e9f891L, 0x0a932f745f03ce02L,
                0xcd820d48a53d95b7L, 0x8f72eca30cd7a324L,
                0x0150a8daf8ab144eL, 0x43a04931514122ddL,
                0x84b16b0dab7f7968L, 0xc6418ae602954ffbL,
                0xbc387aea7a8da4c0L, 0xfec89b01d3679253L,
                0x39d9b93d2959c9e6L, 0x7b2958d680b3ff75L,
                0xf50b1caf74cf481fL, 0xb7fbfd44dd257e8cL,
                0x70eadf78271b2539L, 0x321a3e938ef113aaL,
                0x2e5eb66066087d7eL, 0x6cae578bcfe24bedL,
                0xabbf75b735dc1058L, 0xe94f945c9c3626cbL,
                0x676dd025684a91a1L, 0x259d31cec1a0a732L,
                0xe28c13f23b9efc87L, 0xa07cf2199274ca14L,
                0x167ff3eacbaf2af1L, 0x548f120162451c62L,
                0x939e303d987b47d7L, 0xd16ed1d631917144L,
                0x5f4c95afc5edc62eL, 0x1dbc74446c07f0bdL,
                0xdaad56789639ab08L, 0x985db7933fd39d9bL,
                0x84193f60d72af34fL, 0xc6e9de8b7ec0c5dcL,
                0x01f8fcb784fe9e69L, 0x43081d5c2d14a8faL,
                0xcd2a5925d9681f90L, 0x8fdab8ce70822903L,
                0x48cb9af28abc72b6L, 0x0a3b7b1923564425L,
                0x70428b155b4eaf1eL, 0x32b26afef2a4998dL,
                0xf5a348c2089ac238L, 0xb753a929a170f4abL,
                0x3971ed50550c43c1L, 0x7b810cbbfce67552L,
                0xbc902e8706d82ee7L, 0xfe60cf6caf321874L,
                0xe224479f47cb76a0L, 0xa0d4a674ee214033L,
                0x67c58448141f1b86L, 0x253565a3bdf52d15L,
                0xab1721da49899a7fL, 0xe9e7c031e063acecL,
                0x2ef6e20d1a5df759L, 0x6c0603e6b3b7c1caL,
                0xf6fae5c07d3274cdL, 0xb40a042bd4d8425eL,
                0x731b26172ee619ebL, 0x31ebc7fc870c2f78L,
                0xbfc9838573709812L, 0xfd39626eda9aae81L,
                0x3a28405220a4f534L, 0x78d8a1b9894ec3a7L,
                0x649c294a61b7ad73L, 0x266cc8a1c85d9be0L,
                0xe17dea9d3263c055L, 0xa38d0b769b89f6c6L,
                0x2daf4f0f6ff541acL, 0x6f5faee4c61f773fL,
                0xa84e8cd83c212c8aL, 0xeabe6d3395cb1a19L,
                0x90c79d3fedd3f122L, 0xd2377cd44439c7b1L,
                0x15265ee8be079c04L, 0x57d6bf0317edaa97L,
                0xd9f4fb7ae3911dfdL, 0x9b041a914a7b2b6eL,
                0x5c1538adb04570dbL, 0x1ee5d94619af4648L,
                0x02a151b5f156289cL, 0x4051b05e58bc1e0fL,
                0x87409262a28245baL, 0xc5b073890b687329L,
                0x4b9237f0ff14c443L, 0x0962d61b56fef2d0L,
                0xce73f427acc0a965L, 0x8c8315cc052a9ff6L,
                0x3a80143f5cf17f13L, 0x7870f5d4f51b4980L,
                0xbf61d7e80f251235L, 0xfd913603a6cf24a6L,
                0x73b3727a52b393ccL, 0x31439391fb59a55fL,
                0xf652b1ad0167feeaL, 0xb4a25046a88dc879L,
                0xa8e6d8b54074a6adL, 0xea16395ee99e903eL,
                0x2d071b6213a0cb8bL, 0x6ff7fa89ba4afd18L,
                0xe1d5bef04e364a72L, 0xa3255f1be7dc7ce1L,
                0x64347d271de22754L, 0x26c49cccb40811c7L,
                0x5cbd6cc0cc10fafcL, 0x1e4d8d2b65facc6fL,
                0xd95caf179fc497daL, 0x9bac4efc362ea149L,
                0x158e0a85c2521623L, 0x577eeb6e6bb820b0L,
                0x906fc95291867b05L, 0xd29f28b9386c4d96L,
                0xcedba04ad0952342L, 0x8c2b41a1797f15d1L,
                0x4b3a639d83414e64L, 0x09ca82762aab78f7L,
                0x87e8c60fded7cf9dL, 0xc51827e4773df90eL,
                0x020905d88d03a2bbL, 0x40f9e43324e99428L,
                0x2cffe7d5975e55e2L, 0x6e0f063e3eb46371L,
                0xa91e2402c48a38c4L, 0xebeec5e96d600e57L,
                0x65cc8190991cb93dL, 0x273c607b30f68faeL,
                0xe02d4247cac8d41bL, 0xa2dda3ac6322e288L,
                0xbe992b5f8bdb8c5cL, 0xfc69cab42231bacfL,
                0x3b78e888d80fe17aL, 0x7988096371e5d7e9L,
                0xf7aa4d1a85996083L, 0xb55aacf12c735610L,
                0x724b8ecdd64d0da5L, 0x30bb6f267fa73b36L,
                0x4ac29f2a07bfd00dL, 0x08327ec1ae55e69eL,
                0xcf235cfd546bbd2bL, 0x8dd3bd16fd818bb8L,
                0x03f1f96f09fd3cd2L, 0x41011884a0170a41L,
                0x86103ab85a2951f4L, 0xc4e0db53f3c36767L,
                0xd8a453a01b3a09b3L, 0x9a54b24bb2d03f20L,
                0x5d45907748ee6495L, 0x1fb5719ce1045206L,
                0x919735e51578e56cL, 0xd367d40ebc92d3ffL,
                0x1476f63246ac884aL, 0x568617d9ef46bed9L,
                0xe085162ab69d5e3cL, 0xa275f7c11f7768afL,
                0x6564d5fde549331aL, 0x279434164ca30589L,
                0xa9b6706fb8dfb2e3L, 0xeb46918411358470L,
                0x2c57b3b8eb0bdfc5L, 0x6ea7525342e1e956L,
                0x72e3daa0aa188782L, 0x30133b4b03f2b111L,
                0xf7021977f9cceaa4L, 0xb5f2f89c5026dc37L,
                0x3bd0bce5a45a6b5dL, 0x79205d0e0db05dceL,
                0xbe317f32f78e067bL, 0xfcc19ed95e6430e8L,
                0x86b86ed5267cdbd3L, 0xc4488f3e8f96ed40L,
                0x0359ad0275a8b6f5L, 0x41a94ce9dc428066L,
                0xcf8b0890283e370cL, 0x8d7be97b81d4019fL,
                0x4a6acb477bea5a2aL, 0x089a2aacd2006cb9L,
                0x14dea25f3af9026dL, 0x562e43b4931334feL,
                0x913f6188692d6f4bL, 0xd3cf8063c0c759d8L,
                0x5dedc41a34bbeeb2L, 0x1f1d25f19d51d821L,
                0xd80c07cd676f8394L, 0x9afce626ce85b507L
    };
    private UInt64[] CRC64_Table;

    /**
     * Predefined CRC64 table
     * */
    private static final UInt64[] PRE_CRC64_Table
            = { new UInt64("0000000000000000"), new UInt64("01b0000000000000"), new UInt64("0360000000000000"), new UInt64("02d0000000000000")
            , new UInt64("06c0000000000000"), new UInt64("0770000000000000"), new UInt64("05a0000000000000"), new UInt64("0410000000000000")
            , new UInt64("0d80000000000000"), new UInt64("0c30000000000000"), new UInt64("0ee0000000000000"), new UInt64("0f50000000000000")
            , new UInt64("0b40000000000000"), new UInt64("0af0000000000000"), new UInt64("0820000000000000"), new UInt64("0990000000000000")
            , new UInt64("1b00000000000000"), new UInt64("1ab0000000000000"), new UInt64("1860000000000000"), new UInt64("19d0000000000000")
            , new UInt64("1dc0000000000000"), new UInt64("1c70000000000000"), new UInt64("1ea0000000000000"), new UInt64("1f10000000000000")
            , new UInt64("1680000000000000"), new UInt64("1730000000000000"), new UInt64("15e0000000000000"), new UInt64("1450000000000000")
            , new UInt64("1040000000000000"), new UInt64("11f0000000000000"), new UInt64("1320000000000000"), new UInt64("1290000000000000")
            , new UInt64("3600000000000000"), new UInt64("37b0000000000000"), new UInt64("3560000000000000"), new UInt64("34d0000000000000")
            , new UInt64("30c0000000000000"), new UInt64("3170000000000000"), new UInt64("33a0000000000000"), new UInt64("3210000000000000")
            , new UInt64("3b80000000000000"), new UInt64("3a30000000000000"), new UInt64("38e0000000000000"), new UInt64("3950000000000000")
            , new UInt64("3d40000000000000"), new UInt64("3cf0000000000000"), new UInt64("3e20000000000000"), new UInt64("3f90000000000000")
            , new UInt64("2d00000000000000"), new UInt64("2cb0000000000000"), new UInt64("2e60000000000000"), new UInt64("2fd0000000000000")
            , new UInt64("2bc0000000000000"), new UInt64("2a70000000000000"), new UInt64("28a0000000000000"), new UInt64("2910000000000000")
            , new UInt64("2080000000000000"), new UInt64("2130000000000000"), new UInt64("23e0000000000000"), new UInt64("2250000000000000")
            , new UInt64("2640000000000000"), new UInt64("27f0000000000000"), new UInt64("2520000000000000"), new UInt64("2490000000000000")
            , new UInt64("6c00000000000000"), new UInt64("6db0000000000000"), new UInt64("6f60000000000000"), new UInt64("6ed0000000000000")
            , new UInt64("6ac0000000000000"), new UInt64("6b70000000000000"), new UInt64("69a0000000000000"), new UInt64("6810000000000000")
            , new UInt64("6180000000000000"), new UInt64("6030000000000000"), new UInt64("62e0000000000000"), new UInt64("6350000000000000")
            , new UInt64("6740000000000000"), new UInt64("66f0000000000000"), new UInt64("6420000000000000"), new UInt64("6590000000000000")
            , new UInt64("7700000000000000"), new UInt64("76b0000000000000"), new UInt64("7460000000000000"), new UInt64("75d0000000000000")
            , new UInt64("71c0000000000000"), new UInt64("7070000000000000"), new UInt64("72a0000000000000"), new UInt64("7310000000000000")
            , new UInt64("7a80000000000000"), new UInt64("7b30000000000000"), new UInt64("79e0000000000000"), new UInt64("7850000000000000")
            , new UInt64("7c40000000000000"), new UInt64("7df0000000000000"), new UInt64("7f20000000000000"), new UInt64("7e90000000000000")
            , new UInt64("5a00000000000000"), new UInt64("5bb0000000000000"), new UInt64("5960000000000000"), new UInt64("58d0000000000000")
            , new UInt64("5cc0000000000000"), new UInt64("5d70000000000000"), new UInt64("5fa0000000000000"), new UInt64("5e10000000000000")
            , new UInt64("5780000000000000"), new UInt64("5630000000000000"), new UInt64("54e0000000000000"), new UInt64("5550000000000000")
            , new UInt64("5140000000000000"), new UInt64("50f0000000000000"), new UInt64("5220000000000000"), new UInt64("5390000000000000")
            , new UInt64("4100000000000000"), new UInt64("40b0000000000000"), new UInt64("4260000000000000"), new UInt64("43d0000000000000")
            , new UInt64("47c0000000000000"), new UInt64("4670000000000000"), new UInt64("44a0000000000000"), new UInt64("4510000000000000")
            , new UInt64("4c80000000000000"), new UInt64("4d30000000000000"), new UInt64("4fe0000000000000"), new UInt64("4e50000000000000")
            , new UInt64("4a40000000000000"), new UInt64("4bf0000000000000"), new UInt64("4920000000000000"), new UInt64("4890000000000000")
            , new UInt64("d800000000000000"), new UInt64("d9b0000000000000"), new UInt64("db60000000000000"), new UInt64("dad0000000000000")
            , new UInt64("dec0000000000000"), new UInt64("df70000000000000"), new UInt64("dda0000000000000"), new UInt64("dc10000000000000")
            , new UInt64("d580000000000000"), new UInt64("d430000000000000"), new UInt64("d6e0000000000000"), new UInt64("d750000000000000")
            , new UInt64("d340000000000000"), new UInt64("d2f0000000000000"), new UInt64("d020000000000000"), new UInt64("d190000000000000")
            , new UInt64("c300000000000000"), new UInt64("c2b0000000000000"), new UInt64("c060000000000000"), new UInt64("c1d0000000000000")
            , new UInt64("c5c0000000000000"), new UInt64("c470000000000000"), new UInt64("c6a0000000000000"), new UInt64("c710000000000000")
            , new UInt64("ce80000000000000"), new UInt64("cf30000000000000"), new UInt64("cde0000000000000"), new UInt64("cc50000000000000")
            , new UInt64("c840000000000000"), new UInt64("c9f0000000000000"), new UInt64("cb20000000000000"), new UInt64("ca90000000000000")
            , new UInt64("ee00000000000000"), new UInt64("efb0000000000000"), new UInt64("ed60000000000000"), new UInt64("ecd0000000000000")
            , new UInt64("e8c0000000000000"), new UInt64("e970000000000000"), new UInt64("eba0000000000000"), new UInt64("ea10000000000000")
            , new UInt64("e380000000000000"), new UInt64("e230000000000000"), new UInt64("e0e0000000000000"), new UInt64("e150000000000000")
            , new UInt64("e540000000000000"), new UInt64("e4f0000000000000"), new UInt64("e620000000000000"), new UInt64("e790000000000000")
            , new UInt64("f500000000000000"), new UInt64("f4b0000000000000"), new UInt64("f660000000000000"), new UInt64("f7d0000000000000")
            , new UInt64("f3c0000000000000"), new UInt64("f270000000000000"), new UInt64("f0a0000000000000"), new UInt64("f110000000000000")
            , new UInt64("f880000000000000"), new UInt64("f930000000000000"), new UInt64("fbe0000000000000"), new UInt64("fa50000000000000")
            , new UInt64("fe40000000000000"), new UInt64("fff0000000000000"), new UInt64("fd20000000000000"), new UInt64("fc90000000000000")
            , new UInt64("b400000000000000"), new UInt64("b5b0000000000000"), new UInt64("b760000000000000"), new UInt64("b6d0000000000000")
            , new UInt64("b2c0000000000000"), new UInt64("b370000000000000"), new UInt64("b1a0000000000000"), new UInt64("b010000000000000")
            , new UInt64("b980000000000000"), new UInt64("b830000000000000"), new UInt64("bae0000000000000"), new UInt64("bb50000000000000")
            , new UInt64("bf40000000000000"), new UInt64("bef0000000000000"), new UInt64("bc20000000000000"), new UInt64("bd90000000000000")
            , new UInt64("af00000000000000"), new UInt64("aeb0000000000000"), new UInt64("ac60000000000000"), new UInt64("add0000000000000")
            , new UInt64("a9c0000000000000"), new UInt64("a870000000000000"), new UInt64("aaa0000000000000"), new UInt64("ab10000000000000")
            , new UInt64("a280000000000000"), new UInt64("a330000000000000"), new UInt64("a1e0000000000000"), new UInt64("a050000000000000")
            , new UInt64("a440000000000000"), new UInt64("a5f0000000000000"), new UInt64("a720000000000000"), new UInt64("a690000000000000")
            , new UInt64("8200000000000000"), new UInt64("83b0000000000000"), new UInt64("8160000000000000"), new UInt64("80d0000000000000")
            , new UInt64("84c0000000000000"), new UInt64("8570000000000000"), new UInt64("87a0000000000000"), new UInt64("8610000000000000")
            , new UInt64("8f80000000000000"), new UInt64("8e30000000000000"), new UInt64("8ce0000000000000"), new UInt64("8d50000000000000")
            , new UInt64("8940000000000000"), new UInt64("88f0000000000000"), new UInt64("8a20000000000000"), new UInt64("8b90000000000000")
            , new UInt64("9900000000000000"), new UInt64("98b0000000000000"), new UInt64("9a60000000000000"), new UInt64("9bd0000000000000")
            , new UInt64("9fc0000000000000"), new UInt64("9e70000000000000"), new UInt64("9ca0000000000000"), new UInt64("9d10000000000000")
            , new UInt64("9480000000000000"), new UInt64("9530000000000000"), new UInt64("97e0000000000000"), new UInt64("9650000000000000")
            , new UInt64("9240000000000000"), new UInt64("93f0000000000000"), new UInt64("9120000000000000"), new UInt64("9090000000000000")};

    /**
     * CRC 테이블의 초기화에 높은 비용이 소모되므로, 인스턴스 내 CRC Table의 공유를 위해 싱글톤 인스턴스화
     * */
    public static CRC64 getInstance()
    {
        if (instance == null)
        {
            synchronized (CRC64.class)
            {
                if (instance == null)
                {
                    instance = new CRC64();
                }
            }
        }
        return instance;
    }

    private static class UInt64
    {
        long[] hilo = new long[2];
        String hex = null;

        UInt64(long fromLong)
        {
            this.hex = String.format(Locale.US, "%016x", fromLong);
            this.hilo = unsignedLongLong(this.hex);
        }

        UInt64(String fromHex)
        {
            this.hex = fromHex;
            this.hilo = unsignedLongLong(fromHex);
        }

        UInt64(long[] hilo)
        {
            this.hilo = hilo;
            this.hex = unsignedLongLong(hilo);
        }

        UInt64 bitShiftRight(int shift)
        {
            long hi = hilo[0];
            long lo = hilo[1];
            long[] hilo = new long[2];

            if (shift > 64)
            {
                //Do nothing otherwise
                hilo = new long[]{0, 0};
            }
            else if (shift > 32)
            {
                lo = hi;
                lo = lo >> (shift - 32);

                // hilo[0] is always 0
                hilo[1] = lo;
            }
            else if (shift > 0)
            {
                lo = lo >> shift;
                long leftover = (hi % ((long) 1 << shift));
                hi = hi >> shift;
                lo = lo | (leftover << (32 - shift));

                hilo[0] = hi;
                hilo[1] = lo;
            }

            return new UInt64(hilo);
        }

        long twoBytesLowestMask()
        {
            return this.hilo[1] & 0xFF;
        }

        /**
         * XOR mask
         * */
        UInt64 xorMask(UInt64 with)
        {
            if (hex != null)
            {
                hilo = unsignedLongLong(hex);
            }

            if (with.hex != null)
            {
                with.hilo = unsignedLongLong(with.hex);
            }

            long[] hilo = new long[2];

            hilo[0] = this.hilo[0] ^ with.hilo[0];
            hilo[1] = this.hilo[1] ^ with.hilo[1];

            UInt64 result = new UInt64(hilo);
            result.hex = unsignedLongLong(hilo);

            return result;
        }

        boolean equals(long with)
        {
            UInt64 compare = new UInt64(with);

            return (hilo[0] == compare.hilo[0] && hilo[1] == compare.hilo[1]);
        }

        UInt64 and(UInt64 with)
        {
            long[] hilo = new long[2];

            hilo[0] = this.hilo[0] & with.hilo[0];
            hilo[1] = this.hilo[1] & with.hilo[1];

            return new UInt64(hilo);
        }

        /**
         * @param hexTarget Value string
         * @return hi(0) and lo(1) of unsigned long long
         * */
        protected long[] unsignedLongLong(String hexTarget)
        {
            if (hexTarget.length() != 16)
            {
                //Must be 16 bytes (256 bits)
                return new long[]{0, 0};
            }
            String hi = hexTarget.substring(0, 8);
            String lo = hexTarget.substring(8, 16);

            return new long[]{Long.parseLong(hi, 16), Long.parseLong(lo, 16)};
        }

        /**
         * @param value hi and lo of unsigned long long
         *              Radix must be 16
         * @return hexString
         * */
        protected String unsignedLongLong(long[] value)
        {
            long hi = value[0];
            long lo = value[1];
            return String.format(Locale.US, "%08x%08x", hi, lo);
        }

        protected String toDecimalString()
        {
            return new BigInteger(hex, 16).toString();
        }

        protected String to64BitBinaryString()
        {
            return String.format("%32s%32s",
                            Long.toBinaryString(hilo[0]),
                            Long.toBinaryString(hilo[1]))
                    .replace(" ", "0");
        }
    }

    /**
     * Make CRC64 Table
     * Approx. 400 - 1200ms cost
     * */
    private void makeCRC64Table()
    {
        CRC64_Table = new UInt64[256];
        UInt64 mask = new UInt64(POLY64REV);

        for(int index = 0; index < 256; index ++)
        {
            UInt64 uInt64 = new UInt64(index);

            for (int byteIndex = 0; byteIndex < 8; byteIndex++)
            {
                if (uInt64.and(new UInt64(1)).equals(1))
                {
                    uInt64 = uInt64.bitShiftRight(1).xorMask(mask);
                }
                else
                {
                    uInt64 = uInt64.bitShiftRight(1);
                }
            }
            CRC64_Table[index] = uInt64;
        }
        prepared = true;
    }

    public @NonNull String updateCRC64(@NonNull String string)
    {
        // Use statically defined CRC table instead
        // See PRE_CRC64_Table
        /*if (!prepared)
        {
            synchronized (this)
            {
                makeCRC64Table();
            }
        }*/

        UInt64 crc = new UInt64(INITIALCRC64);
        byte[] bytes = string.getBytes();

        for(int index = 0; index < string.length(); index++)
        {
            long bufferValue = bytes[index] & 0xFF;
            int tableIndex = (int)(crc.xorMask(new UInt64(bufferValue)).twoBytesLowestMask());

            crc = PRE_CRC64_Table[tableIndex].xorMask(crc.bitShiftRight(8));
        }

        Log.d("StoreInfo*Task->CRC64", "crc.hex : " + crc.hex);
        BigInteger result = new BigInteger(crc.hex, 16);
        return result.toString();
    }

    public @NonNull String updateGenericACRC64(long crc, @NonNull byte[] __pbData, int length)
    {
        long ulCrc64 = ~crc;
        int index = 0;
        while (length-- > 0)
        {
            int __tab_index = ((int) (ulCrc64 >> 56) ^ __pbData[index]) & 0xFF;
            ulCrc64 = ACRC64_Table[__tab_index] ^ (ulCrc64 << 8);
        }
        return String.format(Locale.US, "%016x", ~ulCrc64);
    }
}
