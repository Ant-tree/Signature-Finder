/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.ahnlab.enginesdk.SDKManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.IllegalFormatException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class StoreInfoScannerTask
{
    private final Context context;
    private final SignatureFinder signatureFinder;
    private Map<String, String> cacheMap = null;        //HashMap
    private Map<String, String> requestDataMap = null;  //LinkedHashMap
    static String baseDir;
    private static final String TAG = "StoreInfoScannerTask";

    public StoreInfoScannerTask(Context context)
    {
        this.context = context;
        signatureFinder = new SignatureFinder();
        baseDir = context.getFilesDir() + StoreInfoConstants.engineDir;
    }

    @Nullable
    ArrayList<String> scanTrustedPackages(@NonNull String baseUrl, int ttlDays, Set<String> excludedInstaller) {
        ArrayList<String> trustedPackages = new ArrayList<>();

        Map<String, Integer> responseParsed = scan(baseUrl
                , ttlDays
                , excludedInstaller);

        if (responseParsed == null)
        {
            return null;
        }

        //Add packages in cached, previous results into result list
        for(Map.Entry<String, String> entry : cacheMap.entrySet())
        {
            String packageName = entry.getKey();
            trustedPackages.add(packageName);
        }

        //Save cache as-is
        StoreInfoScannerCache.saveCaches(
                baseDir + StoreInfoConstants.scannerCachePath
                , cacheMap
                , context.getPackageName());

        return trustedPackages;
    }

    @Nullable
    Map<String, Integer> scan(@NonNull String baseUrl, int ttlDays, Set<String> excludedInstaller)
    {
        long current = System.currentTimeMillis();
        JSONObject requestData = getRequestData(ttlDays, excludedInstaller);
        Log.d(TAG, "Request data readied in : " + (System.currentTimeMillis() - current) + "ms");
        //Nothing to query
        //This happens when cache knows every result
        if(requestData == null)
        {
            //returns empty hashmap to indicate "NOT QUERIED"
            return new HashMap<>();
        }

        StoreInfoHttpsClient httpsClient = new StoreInfoHttpsClient(baseUrl);

        StoreInfoHttpsClient.Response response = httpsClient.requestScan(StoreInfoConstants.scanApiPath
                , baseDir + StoreInfoConstants.cerPath
                , requestData.toString());

        if (response == null)
        {
            return null;
        }

        Log.d(TAG, "response : " + response);
        ArrayList<String> packages = new ArrayList<>(requestDataMap.keySet());
        for(String pkgName: packages)
        {
            Log.d(TAG, "package : " + pkgName);
        }

        Map<String, Integer> responseParsed = httpsClient.parseScanResult(response.getData()
                , new ArrayList<>(requestDataMap.keySet()));

        if (responseParsed == null)
        {
            return null;
        }

        //put new trusted packages into cache map
        for(Map.Entry<String, Integer> entry : responseParsed.entrySet())
        {
            if (entry.getValue() == StoreInfoConstants.SCANNED_TRUSTED_PACKAGE)
            {
                String packageName = entry.getKey();
                cacheMap.put(packageName, requestDataMap.get(packageName));
            }
        }

        //Parse response from server
        return responseParsed;
    }

    /**
     *
     * @param ttlDays cache 항목에 대해 만료 처리할 ttl
     *                동적으로 변경될 수 있으며, 저장된지 ttlDays에 명시된 기간을 초과한 항목은 삭제된다
     * @return 쿼리할 항목이 하나도 없는 경우 : null 반환
     * 그 외 : 서버 요청을 위한 json 데이터 반환
     * */
    @Nullable
    JSONObject getRequestData(int ttlDays, Set<String> excludedInstaller)
    {
        PackageManager packageManager = context.getPackageManager();
        //Data only request
        JSONObject requestData = new JSONObject();
        JSONObject jsonObject = new JSONObject();

        cacheMap = StoreInfoScannerCache.loadScanCaches(baseDir
                        + StoreInfoConstants.scannerCachePath
                , context.getPackageName());

        //Data to parse the response & cache saving
        requestDataMap = new LinkedHashMap<>();

        @SuppressLint("QueryPermissionsNeeded")
        List<ApplicationInfo> installed = packageManager.getInstalledApplications(0);

        for (ApplicationInfo info : installed)
        {
            String packageName = info.packageName;
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 1)
            {
                continue;
            }

            Log.d(TAG, "package name : " + packageName);
            Log.d(TAG, "package source : " + info.publicSourceDir);

            String installer = getInstallerPackageName(packageManager, packageName);
            if (excludedInstaller != null && excludedInstaller.contains(installer))
            {
                Log.d(TAG, "This package installer is in exclusion list");
                continue;
            }

            byte[] signatureBytes = getFirstSignatureBytes(packageManager, info);

            if (signatureBytes == null)
            {
                //Unable to get first signature
                Log.d(TAG, "Unable to get first signature");
                continue;
            }

            String crcString = calculateCRC(signatureBytes);
            if (crcString == null)
            {
                Log.d(TAG, "Unable to resolve cert CRC");
                continue;
            }

            if (StoreInfoScannerCache.checkCacheContains(cacheMap
                    , packageName
                    , crcString
                    , ttlDays) == StoreInfoScannerCache.CACHE_EXISTS)
            {
                continue;
            }

            int index = requestDataMap.size();
            try
            {
                jsonObject.putOpt(packageName, index + "-" + crcString);
            } catch (JSONException ignore) {
                //ignorable when value is not an instance of Number
            }

            requestDataMap.put(packageName
                    , crcString
                    + StoreInfoScannerCache.ITEM_DELIMITER
                    + System.currentTimeMillis());
        }

        if(jsonObject.length() < 1)
        {
            return null;
        }

        try
        {
            requestData.put("scanData", jsonObject);
        } catch (JSONException e)
        {
            e.printStackTrace();
        }

        return requestData;
    }

    private @Nullable String getInstallerPackageName(PackageManager packageManager, String packageName)
    {
        try
        {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    ? packageManager.getInstallSourceInfo(packageName).getInstallingPackageName()
                    : packageManager.getInstallerPackageName(packageName);
        } catch (PackageManager.NameNotFoundException | IllegalArgumentException e)
        {
            //Given package is not installed
            return "";
        }
    }

    private String calculateCRC(byte[] signatureBytes)
    {
        try
        {
            SDKManager sdkManager = SDKManager.getInstance();
            if (sdkManager == null)
            {
                Log.d(TAG, "sdkManager not initialized");
                return null;
            }
            long crc = SDKManager.getInstance().updateGenericACRC64(signatureBytes);
            return String.format(Locale.US, "%016x", crc);
        } catch (IllegalStateException | IllegalFormatException e)
        {
            Log.d(TAG, "sdkManager not initialized or unable to get crc");
            return null;
        }
    }

    @Nullable
    private PackageInfo getSignaturePackageInfo(PackageManager packageManager, String packageName)
    {
        try
        {
            return packageManager.getPackageInfo(packageName,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                            ? PackageManager.GET_SIGNING_CERTIFICATES
                            : PackageManager.GET_SIGNATURES);
        } catch (PackageManager.NameNotFoundException e)
        {
            return null;
        }
    }

    /**
     * 가장 높은 버전의 signature scheme에서, 가장 첫번째 시그니처 데이터를 반환한다.
     * API 28을 기준으로 분기가 이루어지는데, 28인 경우에는 SigningInfo 클래스에 제공되는 API를 통해 해당 데이터를 수집한다.
     * 만약 API 28 미만인 경우 APK 파일에서부터 시그니처를 파싱한다.
     * SignatureFinder를 통한 시그니처 파싱은 APK Scheme version 2 & 3만 이루어지며, 해당 시그니쳐가 둘 다 없는 경우에는
     * Scheme version 1의 서명을 가져온다.
     * 이 때는 deprecate 된 packageInfo.signatures를 사용한다
     * (항상 가장 오래된 cert (original certificate)만을 가져옴)
     *
     * @param packageManager
     * @param info
     * @return
     * */
    @Nullable
    private byte[] getFirstSignatureBytes(PackageManager packageManager, ApplicationInfo info)
    {
        Signature[] signatures;
        byte[] signatureData = null;

        String publicSource = info.publicSourceDir;
        if (publicSource != null)
        {
            signatureData = signatureFinder.findCertSignature(publicSource);
        }

        return signatureData;

        /*
        if(signatureData != null)
        {
            return signatureData;
        }

        PackageInfo packageInfo = getSignaturePackageInfo(packageManager, info.packageName);
        if (packageInfo == null)
        {
            return null;
        }

        //if certificate with signature scheme v2 or v3 is not found:
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
        {
            SigningInfo signingInfo = packageInfo.signingInfo;

            //If enabled, apk is multiple signed with different certificate,
            //to target multiple app store using different certificate
            boolean hasMultipleSigner = signingInfo.hasMultipleSigners();

            //If so, past signatures will be ignored (only current signature exists)
            if (hasMultipleSigner)
            {
                //If version 2 and 3 are both empty(version 1 is the only signature exists),
                //past signature will be the same one with current one.
                signatures = signingInfo.getApkContentsSigners();
            }
            else
            {
                //Past signature is at first index(eg. v2), and current signature is at last index(eg. v3)
                signatures = signingInfo.getSigningCertificateHistory();
                //Below means the latest version of signature, but will be same as index 0.
                //signatureData = signatures[signatures.length - 1].toByteArray();
            }
            signatureData = signatures[0].toByteArray();
        }
        else
        {
            //Deprecated field packageInfo.signatures will only returns
            //the oldest signature (if v2, v3 exist, returns v2)
            signatures = packageInfo.signatures;
            if (signatures != null)
            {
                signatureData = packageInfo.signatures[0].toByteArray();
            }
        }*/
    }
}
