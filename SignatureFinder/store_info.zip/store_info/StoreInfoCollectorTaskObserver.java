/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

import android.support.annotation.Nullable;

interface StoreInfoCollectorTaskObserver
{
    void onComplete(@Nullable String result);
}
