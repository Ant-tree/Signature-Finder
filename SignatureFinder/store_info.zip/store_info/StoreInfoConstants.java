/* *****************************************************************************
 *
 *  (C) 2022 AhnLab, Inc. All rights reserved.
 *  Any part of this source code can not be copied with any method without
 *  prior written permission from the author or authorized person.
 *
 ******************************************************************************/
package com.ahnlab.enginesdk.store_info;

public class StoreInfoConstants
{

    /**
     * Basic collection keys
     * */
    static final String apiPath = "/ads";
    static final String scanApiPath = "/scan.jsp";
    public static final String storeCachePath = "store.cache";
    public static final String scannerCachePath = "ads.res.cache";
    public static final String engineDir = "/ahnlab/engine/";
    public static final String cerPath = "tdscer";
    static final String cachesDir = "caches/";
    static final String dataFile = "v3mobiled.v3d";
    static final String certExt = ".ancert";
    static final String undefinedVersion = "UNDEFINED";

    /**
     * Network keys
     * */
    static final String HTTPS = "https://";
    static final int BATCH_SINGLE_REQUEST_LIMIT = 50;
    static final String METHOD_POST = "POST";

    /**
     * Scan response
     * */
    static final int SCANNED_TRUSTED_PACKAGE = 0;
    static final int SCANNED_UNKNOWN_PACKAGE = 1;

    /**
     * Cache Strategy
     * */
    static final int DEFAULT_SCAN_CACHE_TTL_IN_DAYS = 30;
}
